function toggle_not_found(klass){
  if($(klass).length == 0){
    $('.fr-not-found').show()
  }else{
    $('.fr-not-found').hide()
  }           
}


(function( $ ) {
  'use strict';

  if($('#fr-embed-code').length > 0){
    var textBox = document.getElementById("fr-embed-code");
    textBox.onfocus = function() {
        textBox.select();

        // Work around Chrome's little problem
        textBox.onmouseup = function() {
            // Prevent further mouseup intervention
            textBox.onmouseup = null;
            return false;
        };
    };
  }

  $(document).on('keyup', '#livefilter-input', function(){
  	window.live_search = $(this).val();
  	if($('.fr-list-container').hasClass('is-grid')){
  		$('.fr-grid-list-item').each(function(){
  			var search_string = $(this).find('.fr-grid-stats').text() + "" + $(this).find('.fr-grid-title').text();
  			if(window.live_search.toLowerCase() == '' || search_string.toLowerCase().indexOf(window.live_search.toLowerCase()) >= 0){
					$(this).show()
  			}else{
					$(this).hide() 
  			}
  		});
      toggle_not_found('.fr-grid-list-item:visible')
  	}else{
  		$('tr.row').each(function(){
  			var search_string = $(this).find('td:first').text();
  			if(window.live_search.toLowerCase() == '' || search_string.toLowerCase().indexOf(window.live_search.toLowerCase()) >= 0){
					$(this).show()
  			}else{
					$(this).hide()    				
  			}
  		});
      toggle_not_found('tr.row:visible')
  	}
  })

	$('#fr-tabs div.tab-div').hide();
	$('#fr-tabs div:first').show();
	$('#fr-tabs ul li:first').addClass('active');
	 
	$('#fr-tabs ul li a').click(function(){
		$('#fr-tabs ul li').removeClass('active');
		$(this).parent().addClass('active');
		var currentTab = $(this).attr('href');
		$('#fr-tabs div.tab-div').hide();
		$(currentTab).show();
		return false;
	});

})( jQuery );


<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://purecharity.com
 * @since      1.0.0
 *
 * @package    Purecharity_Wp_Fundraisers
 * @subpackage Purecharity_Wp_Fundraisers/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the dashboard-specific stylesheet and JavaScript.
 *
 * @package    Purecharity_Wp_Fundraisers
 * @subpackage Purecharity_Wp_Fundraisers/public
 * @author     Rafael Dalprá <rafael.dalpra@toptal.com>
 */
class Purecharity_Wp_Fundraisers_Public {

	/**
	 * The Giving Circle.
	 *
	 * @since    1.0.0
	 * @access   public
	 * @var      string    $fundraiser    The Giving Circle.
	 */
	public static $fundraiser;

	/**
	 * The Giving Circles collection.
	 *
	 * @since    1.0.0
	 * @access   public
	 * @var      string    $fundraisers    The Giving Circles collection.
	 */
	public static $fundraisers;

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @var      string    $plugin_name       The name of the plugin.
	 * @var      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/public.js', array( 'jquery' ), $this->version, false );

	}

	/**
	 * Not found layout for listing display.
	 *
	 * @since    1.0.0
	 */
	public static function list_not_found($default = true){
		return '<p class="fr-not-found" style="'. ( $default ? '' : 'display:none' ) .'">No Fundraisers Found.</p>' . ($default ? Purecharity_Wp_Base_Public::powered_by() : '');	
	}

	/**
	 * Not found layout for single display.
	 *
	 * @since    1.0.0
	 */
	public static function not_found(){
		return "<p>Fundraiser Not Found.</p>" . Purecharity_Wp_Base_Public::powered_by();;	
	}

	/**
	 * Live filter for table.
	 *
	 * @since    1.0.0
	 */
	public static function live_search(){
		return '
			<div class="fr-filtering">
		 		<fieldset class="livefilter fr-livefilter">
		 			<legend>
		 				<label for="livefilter-input">
		 					<strong>Search Fundraisers:</strong>
		 				</label>
		 			</legend>
		 			<input id="livefilter-input" class="fr-livefilter-input" value="" type="text">
		 		</fieldset>
		 	</div>
		';
	}

	/**
	 * List of Fundraisers, grid option.
	 *
	 * @since    1.0.0
	 */
	public static function listing(){

		$html = self::print_custom_styles() ;
		$html .= '
			<div class="fr-list-container">
			 	'.self::live_search().'
				<table class="fundraiser-table option1">
					<tr>
				    	<th colspan="2">Fundraiser Name</th>
				  	</tr>
		';
		$i = 0;
		foreach(self::$fundraisers->external_fundraisers as $fundraiser){
			$class = $i&1 ? 'odd' : 'even';
			$i += 1;
			$html .= '
				<tr class="row '.$class.'  fundraiser_'.$fundraiser->id.'">
				    <td>'.$fundraiser->name.'</td>
				    <td>
					    <a class="fr-themed-link" href="?slug='.$fundraiser->slug.'">More Info</a> 
					    <a class="donate" href="http://purecharity.com/fundraisers/'.$fundraiser->id.'/fund">Donate Now</a>
					</td>
				 </tr>
			';
		}

  		$html .= '
			</table>
				'.self::list_not_found(false).'
			</div>
		';
		$html .= Purecharity_Wp_Base_Public::powered_by();

		return $html;
	}

	/**
	 * List of Fundraisers.
	 *
	 * @since    1.0.0
	 */
	public static function listing_grid(){

		$html = self::print_custom_styles() ;
		$html .= '<div class="fr-list-container is-grid">'.self::live_search();

		foreach(self::$fundraisers->external_fundraisers as $fundraiser){
			$funded = self::percent(($fundraiser->funding_goal-$fundraiser->funding_needed) ,$fundraiser->funding_goal);
			$html .= '
			 	<div class="fr-grid-list-item fundraiser_'.$fundraiser->id.'">
			 		<div class="fr-grid-list-content">
				 		<div class="fr-listing-avatar-container">
								<div class="fr-listing-avatar" href="#" style="background-image: url('.$fundraiser->images->medium.')"></div>
							</div>
						<div class="fr-grid-item-content">
						<p class="fr-grid-title">'.$fundraiser->name.'</h4>
						<div class="fr-grid-status" title="'.$funded.'">
							<div class="fr-grid-progress" style="width:'.$funded.'%"></div>
						</div>
						<div class="fr-grid-stats">
							<p>Goal: <strong>$'.$fundraiser->funding_goal.'</strong></p>
							<p>Raised: <strong>$'.($fundraiser->funding_goal-$fundraiser->funding_needed).'</strong></p>
						</div>
					</div>
					<ul class="fr-list-actions">
						<li><a class="fr-themed-link" href="?slug='.$fundraiser->slug.'">More Info</a>
						<li><a class="fr-themed-link" target="_blank" href="http://purecharity.com/fundraisers/'.$fundraiser->id.'/fund">Donate Now</a>
					</ul>
			 	</div>
			 	</div>
			';
		}

		$html .= self::list_not_found(false);
  	$html .= '</div>';
    $html .= Purecharity_Wp_Fundraisers_Paginator::page_links(self::$fundraisers->meta);
		$html .= Purecharity_Wp_Base_Public::powered_by();

		return $html;
	}

	/**
	 * List of Last Fundraisers.
	 *
	 * @since    1.0.1
	 */
	public static function listing_last_grid(){

		$html = self::print_custom_styles() ;
		$html .= '<div class="fr-list-container is-grid">';

		foreach(self::$fundraisers->external_fundraisers as $fundraiser){
			$funded = self::percent(($fundraiser->funding_goal-$fundraiser->funding_needed) ,$fundraiser->funding_goal);
			$html .= '
			 	<div class="fr-grid-list-item fundraiser_'.$fundraiser->id.'">
			 		<div class="fr-grid-list-content">
				 		<div class="fr-listing-avatar-container">
								<div class="fr-listing-avatar" href="#" style="background-image: url('.$fundraiser->images->large.')"></div>
							</div>
						<div class="fr-grid-item-content">
						<p class="fr-grid-title">'.$fundraiser->name.'</h4>
						<div class="fr-grid-status" title="'.$funded.'">
							<div class="fr-grid-progress" style="width:'.$funded.'%"></div>
						</div>
						<div class="fr-grid-stats">
							<p>Goal: <strong>$'.$fundraiser->funding_goal.'</strong></p>
							<p>Raised: <strong>$'.($fundraiser->funding_goal-$fundraiser->funding_needed).'</strong></p>
						</div>
					</div>
					<ul class="fr-list-actions">
						<li><a class="fr-themed-link" href="?slug='.$fundraiser->slug.'">More Info</a>
						<li><a class="fr-themed-link" target="_blank" href="http://purecharity.com/fundraisers/'.$fundraiser->id.'/fund">Donate Now</a>
					</ul>
			 	</div>
			 	</div>
			';
		}

		$html .= self::list_not_found(false);
  	$html .= '</div>';

		return $html;
	}

	/**
	 * Single Fundraisers.
	 *
	 * @since    1.0.0
	 */
	public static function show(){

		$start_date = new DateTime(self::$fundraiser->start_date);
		$end_date = new DateTime(self::$fundraiser->end_date);
		$date_diff = $start_date->diff($end_date);
		$funded = self::percent((self::$fundraiser->funding_goal-self::$fundraiser->funding_needed) ,self::$fundraiser->funding_goal);

		$html = self::print_custom_styles() ;
		$html .= '
			<div class="fr-container fundraiser_'.self::$fundraiser->id.'">
				<div class="fr-header">
					<img src="'.self::$fundraiser->images->large.'">
				</div>

				<div class="fr-avatar-container">
					<div class="fr-avatar" href="#" style="background-image: url('.self::$fundraiser->images->small.')"></div>
				</div>

				<div class="fr-name">
					<h3>'.self::$fundraiser->name.'</h3>
				</div>

				<div class="fr-intro">

					<div class="fr-info">
						<p class="fr-location">'.self::$fundraiser->country.'</p>
						<p class="fr-organizer">
							Organized by 
							<a class="fr-themed-link" href="http://purecharity.com/'.self::$fundraiser->field_partner->slug.'">'.self::$fundraiser->field_partner->name.'</a>
						</p>
					</div>

					<div class="fr-donate">
						<a class="fr-pure-button" href="http://purecharity.com/fundraisers/'.self::$fundraiser->id.'/fund">Donate</a>
					</div>
					<div class="fr-single-status-section">
						<div class="fr-single-status">
							<div class="fr-single-progress" style="width:'.$funded.'%"></div>
							<div class="fr-raised">
								<span class="fr-raised-label">Amount Raised</span><span class="fr-raised-amount">$'.(self::$fundraiser->funding_goal-self::$fundraiser->funding_needed).'</span>
							</div>
						</div>
					</div>
				</div>
				<div class="fr-single-info">
					<ul class="fr-single-stats">
						<li><strong>$'.self::$fundraiser->funding_goal.'</strong><br/> <span class="fr-stat-title">One-time Goal</span></li>
						<li><strong>$'.self::$fundraiser->funding_needed.'</strong><br/> <span class="fr-stat-title">Still Needed</span></li>
						<li><strong>'.$date_diff->days.'</strong><br/> <span class="fr-stat-title">Days to Go</span></li>
						<li>
						'.Purecharity_Wp_Base_Public::sharing_links(array(), self::$fundraiser->name." Fundraisers").'
						</li>
					</ul>
				</div>

				<div class="fr-body">
					<div id="fr-tabs">
					   <ul class="fr-tabs-list">
					     <li><a class="fr-themed-link" href="#tab-1">About</a></li>
					     <li><a class="fr-themed-link" href="#tab-2">Updates</a></li>
					     <li><a class="fr-themed-link" href="#tab-3">Backers</a></li>
					     <li><a class="fr-themed-link" href="#tab-4">Tools</a></li>
					   </ul>
					   <div id="tab-1" class="tab-div">'.self::$fundraiser->about.'</div>
					   <div id="tab-2" class="tab-div">
					     	<h4>Updates</h4>
					    	'.self::print_updates().'
					   </div>
					   <div id="tab-3" class="tab-div"><!-- we will need to be able check a box to hide this tab / info in the admin of the plugin -->
					     
					     	<h4>Backers</h4>
					     	'.self::print_backers().'
					   
					   </div>
					   <div id="tab-4" class="tab-div"><!-- this needs to be able to be hidden in the admin-->	
					     	<h3>Tools</h3>
						    <div class="fr-tool-section"><!-- this needs to be able to be hidden in the admin-->	
						    	<h4>Fundraiser for this Cause</h4>
						    	<p>Create a fundraiser for this cause on Pure Charity</p>
						    	<a class="fr-pure-button" href="https://purecharity.com/'.self::$fundraiser->slug.'/copies/new">Fundraise for this Cause</a>
						    </div>
						    <div class="fr-tool-section">
						    	<h4>Embed this Widget</h4>
						    	<textarea id="fr-embed-code" rows="4">'.self::$fundraiser->embed_code.'</textarea>
						    </div>
					   </div>
					 </div>
				</div>
			</div>
		';
		$html .= Purecharity_Wp_Base_Public::powered_by();
		return $html;
	}

	/**
	 * Backers list.
	 *
	 * @since    1.0.0
	 */
	public static function print_backers(){
		if(sizeof(self::$fundraiser->backers) == 0){
			$html = '<p>There are no backers at this time.</p>';
		}else{
			$html = '<ul class="fr-backers">';
			foreach(self::$fundraiser->backers as $backer){
				$html .= '
				  <li>
					  <span class="fr-avatar fr-backer-avatar" href="#" style="background-image: url('.$backer->profile->cover_photo->small->url.')"></span>
						<span class="fr-backer-name"><a class="fr-themed-link" href="http://www.pure-charity-profile-page.com">'.$backer->name.'</a></span>
					</li>
				';
			}
			$html .= '</ul>';
		}
		return $html;
	}

	/**
	 * Updates list.
	 *
	 * @since    1.0.0
	 */
	public static function print_updates(){
		if(sizeof(self::$fundraiser->updates) == 0){
			$html = '<p>There are no updates at this time.</p>';
		}else{
			$html = '<ul class="fr-updates">';
			foreach(self::$fundraiser->updates as $update){
				$html .= '
					<li>
			     		<h4><a class="fr-themed-link" href="'.$update->url.'">'.$update->body.'</a></h4>
			     		<p class="date">Posted a week ago</p>
			     		<p>'.$update->body.'</p>
			 				<span class="fr-author">
			 					<p>Posted by:<br/><a class="fr-themed-link" href="http://purecharity.com/'.$update->author->slug.'">'.$update->author->name.'</a></p>
			 				</span>
			 				<span class="fr-read-more">
			   				<a class="fr-read-more" href="'.$update->url.'">Read More</a><!-- links to update on pure charity -->
			   			</span>
			     	</li>
				';
			}
			$html .= '</ul>';
		}
		return $html;
	}


	public static function print_custom_styles(){
		$base_settings = get_option( 'pure_base_settings' );
		$pf_settings = get_option( 'purecharity_fundraisers_settings' );

		// Default theme color
		if($pf_settings['plugin_color'] == NULL || $pf_settings['plugin_color'] == ''){
			if($base_settings['main_color'] == NULL || $base_settings['main_color'] == ''){
				$color = '#CA663A';
			}else{
				$color = $base_settings['main_color'];
			}
		}else{
			$color = $pf_settings['plugin_color'];
		}

		$html = '<style>';
		$html .= '
			.fundraiser-table a.donate { background: '.$color.' !important; }
			.fr-grid-progress { background: '.$color.' !important; }
			.fr-grid-list-item ul.fr-list-actions li a:hover { background: '.$color.' !important; }
			a.fr-pure-button { background: '.$color.' !important; }
 			.fr-single-progress { background: '.$color.' !important; }
 			#fr-tabs ul.fr-tabs-list li.active a,
			#fr-tabs ul.fr-tabs-list li a:hover { background: '.$color.' !important; }
			.fr-themed-link { color: '.$color.' !important; }
		';
		$html .= '</style>';

		return $html;
	}


	/**
	 * Updates list.
	 *
	 * @since    1.0.0
	 */
	

	/**
	 * Percentage calculator.
	 *
	 * @since    1.0.0
	 */
	public static function percent($num_amount, $num_total) {
		if($num_total == 0){ return 100; }
		return number_format((($num_amount / $num_total) * 100), 0);
	}
}

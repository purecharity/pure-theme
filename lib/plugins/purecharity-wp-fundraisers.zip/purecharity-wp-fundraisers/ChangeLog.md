# ChangeLog

* (22 January 2015). Added template tag for last fundraisers.
* (22 January 2015). Added shortcode for last fundraisers without branding and pagination.
* (5 November 2014). Added Base Plugin dependency.

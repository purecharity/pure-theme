<?php

/**
 * Used on public display of the Giving Circle(s)
 *
 * @link       http://purecharity.com
 * @since      1.0.0
 *
 * @package    Purecharity_Wp_Fundraisers
 * @subpackage Purecharity_Wp_Fundraisers/includes
 */

/**
 * Used on public display of the Giving Circle(s).
 *
 * This class defines all the shortcodes necessary.
 *
 * @since      1.0.0
 * @package    Purecharity_Wp_Fundraisers
 * @subpackage Purecharity_Wp_Fundraisers/includes
 * @author     Rafael Dalprá <rafael.dalpra@toptal.com>
 */
class Purecharity_Wp_Fundraisers_Shortcode {
 

  /**
   * The Base Plugin.
   *
   * @since    1.0.0
   * @access   public
   * @var      Object    $base_plugin    The Base Plugin.
   */
  public static $base_plugin;

  /**
   * Initialize the class and Base Plugin functionality.
   *
   * @since    1.0.0
   */
  public function __construct() {
    $this->actions = array();
    $this->filters = array();

  }

  /**
   * Initialize the shortcodes to make them available on page runtime.
   *
   * @since    1.0.0
   */
  public static function init()
  {
    add_shortcode('fundraisers', array('Purecharity_Wp_Fundraisers_Shortcode', 'fundraisers_shortcode'));
    add_shortcode('last_fundraisers', array('Purecharity_Wp_Fundraisers_Shortcode', 'last_fundraisers_shortcode'));
    add_shortcode('fundraiser', array('Purecharity_Wp_Fundraisers_Shortcode', 'fundraiser_shortcode'));

    self::$base_plugin = new Purecharity_Wp_Base();
  }

  /**
   * Initialize the Last Fundraisers Listing shortcode.
   *
   * @since    1.0.1
   */
  public static function last_fundraisers_shortcode($atts)
  {
    $options = shortcode_atts( array(
      'slug' => false,
      'limit' => get_query_var('limit')
    ), $atts );
    if(isset($_GET['slug'])){
      $opt = array();
      $opt['slug'] = $_GET['slug'];
      return self::fundraiser_shortcode($opt);
    }else{

      $query_var = array();

      if(isset($options['limit']) && $options['limit'] != ''){
        $query_var[] = 'limit='.$options['limit'];
      }else{
        $query_var[] = 'limit=4';
      }
      
      $fundraisers = self::$base_plugin->api_call('external_fundraisers?' . join('&', $query_var));

      if ($fundraisers && count($fundraisers) > 0) {
        Purecharity_Wp_Fundraisers_Public::$fundraisers = $fundraisers; 
        return Purecharity_Wp_Fundraisers_Public::listing_last_grid();
      }else{
        return Purecharity_Wp_Fundraisers_Public::list_not_found();        
      };
    }
  }

  /**
   * Initialize the Fundraisers Listing shortcode.
   *
   * @since    1.0.0
   */
  public static function fundraisers_shortcode($atts)
  {
    $options = shortcode_atts( array(
      'slug' => false,
      'grid' => get_query_var('grid'),
      'per_page' => get_query_var('per_page')
    ), $atts );
    if(isset($_GET['slug'])){
      $opt = array();
      $opt['slug'] = $_GET['slug'];
      return self::fundraiser_shortcode($opt);
    }else{

      $query_var = array();
      if(isset($_GET['_page']) && $_GET['_page'] != ''){
        $query_var[] = 'page='.$_GET['_page'];
      }
      if(isset($options['per_page']) && $options['per_page'] != ''){
        $query_var[] = 'limit='.$options['per_page'];
      }
      
      $fundraisers = self::$base_plugin->api_call('external_fundraisers?' . join('&', $query_var));

      if ($fundraisers && count($fundraisers) > 0) {
        Purecharity_Wp_Fundraisers_Public::$fundraisers = $fundraisers; 
        if($options['grid'] == 'true'){
          return Purecharity_Wp_Fundraisers_Public::listing_grid();
        }else{
          return Purecharity_Wp_Fundraisers_Public::listing();
        }
      }else{
        return Purecharity_Wp_Fundraisers_Public::list_not_found();        
      };
    }
  }

  /**
   * Initialize the Single Fundraiser shortcode.
   *
   * @since    1.0.0
   */
  public static function fundraiser_shortcode($atts)
  {
    $options = shortcode_atts( array(
      'slug' => false
    ), $atts );

    if ($options['slug']) {
      $fundraiser = self::$base_plugin->api_call('fundraisers/show?slug='. $options['slug']);
      if ($fundraiser) {
        $fundraiser = $fundraiser->fundraiser;
        Purecharity_Wp_Fundraisers_Public::$fundraiser = $fundraiser;
        return Purecharity_Wp_Fundraisers_Public::show();
      }else{
        return Purecharity_Wp_Fundraisers_Public::not_found();       
      }

    }
  }
}
(function( $ ) {
	'use strict';

	$(document).on('change', '.pcsponsor-filters select', function(){
		filterSponsorships();
	})

	$(document).on('click', '.submit', function(){
		$(this).parents('form').submit();
		return false;
	})

})( jQuery );

window.params = {};
var filterSponsorships = function() {
	// Get the values
	var query_string = [];
	if($('select[name=age]').val() != "0"){ query_string.push("age="+$('select[name=age]').val()) }
	if($('select[name=gender]').val() != "0"){ query_string.push("gender="+$('select[name=gender]').val()) }
	if($('select[name=location]').val() != "0"){ query_string.push("location="+$('select[name=location]').val()) }

	location.href = "?"+query_string.join("&")
};
=== Pure Charity Sponsorships ===
Contributors: rafaeldalpra
Donate link: http://purecharity.com/
Tags: purecharity, sponsorships
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin to list and show details about sponsorship programs in your wordpress site.

== Description ==

A plugin to list and show details about sponsorship programs in your wordpress site.

== Installation ==

1. Upload the `purecharity-wp-sponsorships/trunk` folder contents to the `/wp-content/plugins/purecharity-wp-sponsorships` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. You're done!

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.0 =
* First plugin version.

== Upgrade Notice ==

= 1.0 =
Nothing to add yet.

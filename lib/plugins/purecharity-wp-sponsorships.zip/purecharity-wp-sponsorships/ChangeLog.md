# ChangeLog

* (5 November 2014). Added Base Plugin dependency.

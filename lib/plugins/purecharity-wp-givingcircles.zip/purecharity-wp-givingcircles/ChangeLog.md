# ChangeLog

* (10 February 2015). Added a new shortcode.
* (10 November 2014). First version of the plugin.

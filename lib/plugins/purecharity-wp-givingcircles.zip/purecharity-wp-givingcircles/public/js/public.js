(function( $ ) {
  'use strict';
  
  $('#gc-tabs div').hide();
  $('#gc-tabs div:first').show();
  $('#gc-tabs ul li:first').addClass('active');
   
  $('#gc-tabs ul:first li a').click(function(){
    $('#gc-tabs ul:first li').removeClass('active');
    $(this).parent().addClass('active');
    var currentTab = $(this).attr('href');
    $('#gc-tabs div').hide();
    $(currentTab).show();
    return false;
  });

})( jQuery );


=== Pure Charity Fundraisers ===
Contributors: rafaeldalpra
Donate link: http://purecharity.com/
Tags: purecharity, fundraisers
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin designed to show Pure Charity Giving Circles on your wordpress site.

== Description ==

A plugin designed to show Pure Charity Giving Circles on your wordpress site.

== Installation ==

1. Upload the `purecharity-wp-givingcircles/trunk` folder contents to the `/wp-content/plugins/purecharity-wp-givingcircles` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. You're done!

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.1.4 =
* Minor bug fixes.

= 1.1.3 =
* Added options to limite members and backed causes on the GC view.

= 1.1.2 =
* Added GitHub updater process.

= 1.1.2 =
* Added GitHub updater process.

= 1.1.1 =
* Added the option to force a template use for the single view.

= 1.1 =
* Added a new shortcode.

= 1.0 =
* First plugin version.

== Upgrade Notice ==

= 1.1 =
3 new shortcodes available.

= 1.0 =
Nothing to add yet.

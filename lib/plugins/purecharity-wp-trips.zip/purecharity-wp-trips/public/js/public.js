(function( $ ) {
	'use strict';

  $(document).on('keyup', '#livefilter-input', function(){
  	window.live_search = $(this).val();
  	if($('.pctrip-list-container').hasClass('is-grid')){
  		$('.pctrip-grid-list-item').each(function(){
  			var search_string = $(this).find('.pctrip-date').text() + "" + $(this).find('.pctrip-grid-title').text();
  			if(window.live_search.toLowerCase() == '' || search_string.toLowerCase().indexOf(window.live_search.toLowerCase()) >= 0){
					$(this).show()
  			}else{
					$(this).hide() 
  			}
  		});
      toggle_not_found('.pctrip-grid-list-item:visible')
  	}else{
  		$('.pctrip-list-item').each(function(){
  			var search_string = $(this).find('.pctrip-title').text() + "" + $(this).find('.pctrip-date').text() + "" + $(this).find('.pctrip-description').text();
  			if(window.live_search.toLowerCase() == '' || search_string.toLowerCase().indexOf(window.live_search.toLowerCase()) >= 0){
					$(this).show()
  			}else{
					$(this).hide()    				
  			}
  		});
      toggle_not_found('tr.row:visible')
  	}
  })

})( jQuery );

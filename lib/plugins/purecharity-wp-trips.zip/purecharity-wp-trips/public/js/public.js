(function( jQuery ) {
	'use strict';

})( jQuery );

<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://purecharity.com
 * @since      1.0.0
 *
 * @package    Purecharity_Wp_Trips
 * @subpackage Purecharity_Wp_Trips/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the dashboard-specific stylesheet and JavaScript.
 *
 * @package    Purecharity_Wp_Trips
 * @subpackage Purecharity_Wp_Trips/public
 * @author     Rafael Dalprá <rafael.dalpra@toptal.com>
 */
class Purecharity_Wp_Trips_Public {

  const DATE_FORMAT = "F j, Y";
  const MONTH_FORMAT = "F Y";

	/**
	 * The Trip.
	 *
	 * @since    1.0.0
	 * @access   public
	 * @var      string    $event    The Trip.
	 */
	public static $event;

	/**
	 * The Trips collection.
	 *
	 * @since    1.0.0
	 * @access   public
	 * @var      string    $events    The Trips collection.
	 */
	public static $events;

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @var      string    $plugin_name       The name of the plugin.
	 * @var      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/public.js', array( 'jquery' ), $this->version, false );

	}

	/**
	 * Not found layout for listing display.
	 *
	 * @since    1.0.0
	 */
	public static function list_not_found(){
		return "<p>No Trips Found.</p>" . Purecharity_Wp_Base_Public::powered_by();;	
	}

	/**
	 * Not found layout for single display.
	 *
	 * @since    1.0.0
	 */
	public static function not_found(){
		return "<p>Trip Not Found.</p>" . Purecharity_Wp_Base_Public::powered_by();;	
	}

	/**
	 * Live filter template.
	 *
	 * @since    1.0.1
	 */
	public static function live_search(){
		return '
			<div class="fr-filtering">
		 		<fieldset class="livefilter fr-livefilter">
		 			<legend>
		 				<label for="livefilter-input">
		 					<strong>Search Trips:</strong>
		 				</label>
		 			</legend>
		 			<input id="livefilter-input" class="fr-livefilter-input" value="" type="text">
		 		</fieldset>
		 	</div>
		';
	}

	/**
	 * Listing HTML for Trips
	 *
	 * @since    1.0.0
	 */
	public static function listing(){

		$html = '<div class="pctrip-list-container">';
		$html .= self::live_search();

		foreach(self::$events->events as $event){
			$html .= '
			 	<div class="pctrip-list-item">
			 		<div class="pctrip-list-content">
				 		<div class="pctrip-listing-avatar-container">
							<div class="pctrip-listing-avatar" href="#" style="background-image: url('.$event->images->small.')"></div>
						</div>
						<div class="pctrip-list-body-container">
							<h3 class="pctrip-title"><a href="?event_id='.$event->id.'">'.$event->name.'</a></h3>
							<p class="pctrip-date">'.self::get_date_range($event->starts_at, $event->ends_at).'</p>
							<p class="pctrip-description">'.$event->about.'</p>
						</div>
					</div>
					<ul class="pctrip-list-actions">
						<li><a href="?event_id='.$event->id.'">More Info</a></li>
						<li><a target="_blank" href="'.$event->public_url.'">Apply Now</a></li>
					</ul>
			 	</div>
			';

		}

		// Paginator
		if(self::$events->meta->num_pages > 1) {
      $html .= Purecharity_Wp_Trips_Paginator::page_links(self::$events->meta);
    }

		$html .= '</div>';
		return $html;
	}

	/**
	 * Listing HTML for Trips
	 *
	 * @since    1.0.0
	 */
	public static function listing_grid(){
		$html = '<div class="pctrip-list-container is-grid">';
		$html .= self::live_search();


		foreach(self::$events->events as $event){
			$html .= '
			 	<div class="pctrip-grid-list-item">
			 		<div class="pctrip-grid-list-content">
				 		<div class="pctrip-listing-avatar-container">
								<div class="pctrip-grid-listing-avatar" href="?event_id='.$event->id.'" style="background-image: url('.$event->images->large.')"></div>
							</div>
						<div class="pctrip-grid-lower-content">
							<p class="pctrip-grid-title">'.$event->name.'</h4>
							<p class="pctrip-date">'.self::get_date_range($event->starts_at, $event->ends_at).'</p>
					</div>
					<ul class="pctrip-list-actions">
						<li><a target="_blank" href="'.$event->public_url.'">Apply Now</a></li>
					</ul>
					</div>
			 	</div>
		 	';
		}

		// Paginator
		if(self::$events->meta->num_pages > 1) {
      $html .= Purecharity_Wp_Trips_Paginator::page_links(self::$events->meta);
    }

		$html .= '</div>';
		return $html;
	}


	/**
	 * Single HTML for a Trip
	 *
	 * @since    1.0.0
	 */
	public static function show(){

		return '
			<div class="pctrip-container">
 
				<div class="pctrip-header">
					<img src="'.self::$event->images->large.'">
				</div>

				<div class="pctrip-avatar-container">
					<div class="pctrip-avatar" href="#" style="background-image: url('.self::$event->images->small.')"></div>
				</div>

				<div class="pctrip-name">
					<h3>'.self::$event->name.'</h3>
					<p class="pctrip-date">'.self::get_date_range(self::$event->starts_at, self::$event->ends_at).'</p>
				</div>

				<div class="pctrip-register">
					<a class="pctrip-pure-button" href="'.self::$event->public_url.'">Register</a>
				</div>
				
				<div class="pctrip-content">


					<div class="pctrip-body">
						<p>'.self::$event->about.'</p>
					</div>

					<div class="pctrip-sidebar">
					
						<div class="pctrip-sidebarsection">
							<h4>Trip Costs</h4>
							'.self::print_trip_tickets().'
						</div>
						
						<div class="pctrip-sidebarsection">
							<h4>Trip Information</h4>
							<p><strong>Trip Type:</strong> '.self::print_trip_types().'</p>
							<p><strong>Region:</strong> '.self::$event->region.'</p>
							<p><strong>Country:</strong> '.self::$event->country.'</p>
							<p><strong>Tags:</strong> '.self::print_trip_tags().'
						</div>
						
						<div class="pctrip-sidebarsection">
							<h4>Trip Leadership</h4>
							'.self::print_trip_leaders().'
						</div>

					</div>

				</div>

			</div>

		';
	}


	/**
	 * Print the trip leaders
	 *
	 * @since    1.0.0
	 */
	public static function print_trip_leaders(){
		$html = '';
		foreach(self::$event->leaders as $leader){
			$html .= '<p><a href="'.$leader->public_url.'">'.$leader->name.'</a></p>';
		}
		return $html;
	}

	/**
	 * Print the trip tags
	 *
	 * @since    1.0.0
	 */
	public static function print_trip_tags(){
		$tags = array();
		foreach(self::$event->trip_tags as $tag){
			$tags[] = '<a href="?trip_tag='.$tag.'">'.$tag.'</a>';
		}
		return join(', ', $tags);
	}

	/**
	 * Print the trip types
	 *
	 * @since    1.0.0
	 */
	public static function print_trip_types(){
		$types = array();
		foreach(self::$event->types as $type){
			$types[] = $type;
		}
		return join(', ', $types);
	}

	/**
	 * Print the trip tickets
	 *
	 * @since    1.0.0
	 */
	public static function print_trip_tickets(){
		$tickets = '';
		foreach(self::$event->tickets as $ticket){
			$tickets .= '
				<p>
					<strong>'.$ticket->name.'</strong><br /><br />
					<span class="pctrip-ticket-price">$ '.$ticket->price.'</span><br /><br />
					'.$ticket->description.'
				</p>
			';
		}
		return $tickets;
	}


	/**
	 * Calculate date range for a trip
	 *
	 * @since    1.0.0
	 */
  public static function get_date_range($start, $end) {
    $start = strtotime($start);
    $end = strtotime($end);
    $days = ($end - $start) / 3600 / 24;
    if (($days > 31) || date('M',$start) != date('M',$end)) {
      return date(self::DATE_FORMAT, $start) . ' - ' . date(self::DATE_FORMAT, $end);
    } else {
      $parts = preg_split('/([dj])/', self::DATE_FORMAT, -1, PREG_SPLIT_DELIM_CAPTURE);
      $date = '';
      foreach($parts as $part) {
        if ($part == 'd' || $part == 'j') {
          $date .= date($part, $start) . '-' . date($part, $end);
        } else {
          $date .= date($part, $start);
        }
      }
      return $date;
    }
  }

}
